/*jslint node:true*/

var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var oracledb = require('oracledb');
var con = require('./connections.js'); 

// Use body parser to parse JSON body
app.use(bodyParser.json());

var connAttrs = { 
    "user": con.user, 
    "password": con.password, 
    "connectString": con.connectString 
}

// Http Method: GET 
// URI        : /tickets_list
// Read all tickets
app.get('/tickets', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
			console.log("Error")
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT * FROM TICKETS_LIST", {}, {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err) {
                res.set('Content-Type', 'application/json');
                res.status(500).send(JSON.stringify({
                    status: 500,
                    message: "Error getting the tickets list",
                    detailed_message: err.message
                }));
            } else {
				console.log('Selected!')
                res.contentType('application/json').status(200);
                res.send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /tickets_list : Connection released");
                    }
                });
        });
    });
});

// Http method: GET
// URI        : /getProfile/:EMAIL
// Read the profile of user given in :Email
app.get('/getProfile/:user_email', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute(`SELECT * FROM PROFILE WHERE "email" = :id`, [req.params.user_email], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, (err, result) => {
			console.log(result);
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the user profile" : "User doesn't exist",
                    detailed_message: err ? err.message : "not found error"
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /getProfile/" + [req.params.user_email] + " : Connection released");
                    }
                });
        });
    });
});


// Http method: POST
// URI        : /registration
// Creates a new user profile
app.post('/register_user', function (req, res) {
    "use strict";
    if ("application/json" !== req.get('Content-Type')) {
        res.set('Content-Type', 'application/json').status(415).send(JSON.stringify({
            status: 415,
            message: "Wrong content-type. Only application/json is supported",
            detailed_message: null
        }));
        return;
    }
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json').status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
		
		connection.execute("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE; ", {}, (err, result) => {
                if (err) {
                    connection.rollback();
                } else {
					connection.commit();
                }
            });
		
		
        connection.execute("INSERT INTO PROFILE VALUES " +
							 "(:email, :role, :password, :firstname, " +
							 ":lastname, :cardnumber, :adress, :DEL) ", [req.body.user_email, req.body.role_name,
                            req.body.user_password, req.body.user_firstname, req.body.user_lastname, req.body.user_cardnumber,
                            req.body.user_adress, req.body.USER_DELETED], {
				autoCommit: true,
                outFormat: oracledb.OBJECT // Return the result as Object
            },
            function (err, result) {
                if (err) {
                    // Error
                    res.set('Content-Type', 'application/json');
                    res.status(400).send(JSON.stringify({
                        status: 400,
                        message: err.message.indexOf("ORA-00001") > -1 ? "User already exists" : "Input Error",
                        detailed_message: err.message
                    }));
                } else {
                    // Successfully created the resource
					console.log("Created!")

					res.contentType('application/json').status(200).send(JSON.stringify({
					status: 201,
					message: "Registrated"
					}));
                }
                // Release the connection
                connection.release(
                    function (err) {
                        if (err) {
                            console.error(err.message);
                        } else {
                            console.log("POST /registration: Connection released");
                        }
                    });
            });
    });
});


// Http method: GET
// URI        : /login/:EMAIL
// Read the profile of user given in :Email
app.get('/login/:user_email/:user_password', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute('SELECT "PA" FROM (SELECT * FROM LOGIN WHERE "EM" = :id) WHERE "PA" = :ip', 
		{
			id: req.params.user_email,
			ip: req.params.user_password
		}, {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, (err, result) => {

		if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the user profile" : "User doesn't exist",
                    detailed_message: err ? err.message : "not found error"
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify({
					status: 200,
					message: "Logged"
				}));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /logged/" + [req.params.user_email] + [req.params.user_password] + " : Connection released");
                    }
                });
        });
    });
});

var numRows = 50;
// CURSOR 
// GET: get_orders_by/:user_email

app.get('/get_orders_by/:user_email', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
        oracledb.getConnection(connAttrs, function(err, connection)
            {
            if (err) { console.error(err.message); return; }
            var bindvars = {
                email:     req.params.user_email,
                cursor:  { type: oracledb.CURSOR, dir : oracledb.BIND_OUT }
            };
            connection.execute(
                "BEGIN get_emount_orders(:email, :cursor); END;",  
                bindvars,
                function(err, result)
                {
                if (err) {
                    console.error(err.message);
                    doRelease(connection);
                    return;
                }
                console.log(result.outBinds.cursor.metaData);
				
                fetchRowsFromRS(connection, result.outBinds.cursor, numRows);
                });
            });
        
        function fetchRowsFromRS(connection, resultSet, numRows)
        {
            resultSet.getRows( // get numRows rows
            numRows,
            function (err, rows)
            {
                if (err) {
                console.log(err);
               // doClose(connection, resultSet); // always close the ResultSet
			   resultSet.close(
				function(err)
				{
					if (err) { console.error(err.message); }
					
				});
				  doRelease(connection);
                } else if (rows.length === 0) {   // no rows, or no more rows
               // doClose(connection, resultSet); // always close the ResultSe;
			   resultSet.close(
				function(err)
				{
					if (err) { console.error(err.message); }
					
				});
				  doRelease(connection);
                } else if (rows.length > 0) {
                console.log("fetchRowsFromRS(): Got " + rows.length + " rows");
                console.log(rows);
				res.contentType('application/json').status(200).send(JSON.stringify(rows));
                fetchRowsFromRS(connection, resultSet, numRows);
                }
            });
        }
        
        function doRelease(connection)
        {
            connection.release(
                    function (err) {
                        if (err) {
                            console.error(err.message);
                        } else {
                            console.log("POST /order_item: Connection released");
                        }
                    });
        }
        
		function doClose(connection, resultSet)
        {
            resultSet.close(
            function(err)
            {
                if (err) { console.error(err.message); }
                doRelease(connection);
            });
        }
        
    });
});

// Http method: POST
// URI        : /create_order

app.post('/create_order', function (req, res) {
    "use strict";
    if ("application/json" !== req.get('Content-Type')) {
        res.set('Content-Type', 'application/json').status(415).send(JSON.stringify({
            status: 415,
            message: "Wrong content-type. Only application/json is supported",
            detailed_message: null
        }));
        return;
    }
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json').status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
		
		connection.execute("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE; ", {}, (err, result) => {
                if (err) {
                    connection.rollback();
                } else {
					connection.commit();
                }
            });
			
		connection.execute('SELECT "PA" FROM (SELECT * FROM LOGIN WHERE "EM" = :id) WHERE "PA" = :ip',  
            { 
                id: req.body.user_email, 
                ip: req.body.user_password 
            }, { 
                outFormat: oracledb.OBJECT // Return the result as Object 
            }, (err, result) => { 
     
            if (err || result.rows.length < 1) { 
			        connection.rollback();

                    connection.release( 
                        function (err) { 
                            if (err) { 
                                console.error(err.message); 
                            } else {
								res.contentType('application/json').status(200).send(JSON.stringify({
								status: 404,
								message: "order_not_maked"
							}));
                                console.log("Order NotCreated!") 
                                console.log("POST /create_order: Connection released"); 
                            } 
                        });   
                } else { 
				
					connection.execute("INSERT INTO ORD VALUES " + 
									"(:em, (TO_DATE(:or_d, 'yyyy/mm/dd hh24:mi:ss')),:orid)", [req.body.user_email, req.body.order_date, req.body.order_id], {
						autoCommit: true,
						outFormat: oracledb.OBJECT // Return the result as Object
					}, (err, result) => {
						if (err) {
							// Error
							res.set('Content-Type', 'application/json');
							res.status(400).send(JSON.stringify({
								status: 400,
								message: err.message.indexOf("ORA-00001") > -1 ? "Order err" : "Input Error",
								detailed_message: err.message
							}));
							connection.rollback();
						} else {
						  connection.execute(`SELECT "orid" FROM (SELECT "orid" FROM "ORD" WHERE "em" = :id GROUP BY "orid" ORDER BY "orid" DESC) WHERE ROWNUM = 1`, [req.body.user_email], {
						outFormat: oracledb.OBJECT // Return the result as Object
					}, (err, result) => {
						console.log(result);
						if (err || result.rows.length < 1) {
							res.set('Content-Type', 'application/json');
							var status = err ? 500 : 404;
							res.status(status).send(JSON.stringify({
								status: status,
								message: err ? "Error getting the user profile" : "User doesn't exist",
								detailed_message: err ? err.message : "not found error"
							}));
							connection.rollback();
						} else {
							connection.commit();
							res.send(JSON.stringify(result.rows));
						}
					});
							connection.commit();
						}
					});
             } 
            });	
		


        // Release the connection
        connection.release(
            function (err) {
                if (err) {
                    console.error(err.message);
                } else {
                    console.log("Order Created!")
                    console.log("POST /create_order: Connection released");
                }
            });    
    });
});


// Http method: POST
// URI        : /post order item
// Creates a new order_item
app.post('/order_item', function (req, res) {
    "use strict";
    if ("application/json" !== req.get('Content-Type')) {
        res.set('Content-Type', 'application/json').status(415).send(JSON.stringify({
            status: 415,
            message: "Wrong content-type. Only application/json is supported",
            detailed_message: null
        }));
        return;
    }
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json').status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
        connection.execute(	"INSERT INTO ITEM VALUES " +
							"(:i, :type, :em, :orid, :qua)", [req.body.id, req.body.ticket_type, req.body.user_email,
                            req.body.order_id, req.body.tickets_quantity], {
                autoCommit: true,
                outFormat: oracledb.OBJECT // Return the result as Object
            },
            function (err, result) {
                if (err) {
                    // Error
                    res.set('Content-Type', 'application/json');
                    res.status(400).send(JSON.stringify({
                        status: 400,
                        message: err.message.indexOf("ORA-00001") > -1 ? "User already exists" : "Input Error",
                        detailed_message: err.message
                    }));
                connection.rollback();
                } else {
                    // Successfully created the resource
                   res.contentType('application/json').status(200).send(JSON.stringify({
					status: 201,
					message: "SUCCESS"
					}));
                }
                // Release the connection
                connection.release(
                    function (err) {
                        if (err) {
                            console.error(err.message);
                        } else {
                            console.log("POST /order_item: Connection released");
                        }
                    });
            });
    });
});



app.put('/add_tickets', function (req, res) { 
    "use strict"; 
    if ("application/json" !== req.get('Content-Type')) { 
        res.set('Content-Type', 'application/json').status(415).send(JSON.stringify({ 
            status: 415, 
            message: "Wrong content-type. Only application/json is supported", 
            detailed_message: null 
        })); 
        return; 
    } 
    oracledb.getConnection(connAttrs, function (err, connection) { 
        if (err) { 
            // Error connecting to DB 
            res.set('Content-Type', 'application/json').status(500).send(JSON.stringify({ 
                status: 500, 
                message: "Error connecting to DB", 
                detailed_message: err.message 
            })); 
            return; 
        } 
		
		connection.execute("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE; ", {}, (err, result) => {
                if (err) {
                    connection.rollback();
                } else {
					connection.commit();
                }
            });
 
        connection.execute(`SELECT "password" FROM (SELECT * FROM PROFILE WHERE "email" = :id AND "role" = 'Admin') WHERE "password" = :ip`,   
            {  
                id: req.body.email,  
                ip: req.body.password  
            }, {  
                outFormat: oracledb.OBJECT // Return the result as Object  
            }, (err, result) => {  
      
            if (err || result.rows.length < 1) {  
           connection.rollback(); 
                    connection.release(  
                        function (err) {  
                            if (err) {  
                                console.error(err.message);  
                            } else { 
							res.contentType('application/json').status(200).send(JSON.stringify({ 
							status: 404, 
							message: "not_updated" 
						   })); 
                                console.log("update /update: Connection released");  
                            }  
                        });    
                } else {  
				 connection.execute(`UPDATE TICKETS_LIST SET "amount" = :amount WHERE "type" = :type`,  [req.body.amount, req.body.type], { 
				  autoCommit: true, 
				  outFormat: oracledb.OBJECT // Return the result as Object 
				 }, (err, result) => { 
				  if (err) { 
				   // Error 
				   res.set('Content-Type', 'application/json'); 
				   res.status(400).send(JSON.stringify({ 
					status: 400, 
					message: err.message.indexOf("ORA-00001") > -1 ? "update err" : "Input Error", 
					detailed_message: err.message 
				   })); 
				   connection.rollback(); 
				  } else { 
				  res.status(200).send(JSON.stringify({ 
					status: 200, 
					message: "Updated" 
										})); 
				connection.commit(); 
				  } 
				 }); 
             }   
    }); 
});
}); 



app.delete('/del_orderitem', function (req, res) { 
    "use strict"; 
    if ("application/json" !== req.get('Content-Type')) { 
        res.set('Content-Type', 'application/json').status(415).send(JSON.stringify({ 
            status: 415, 
            message: "Wrong content-type. Only application/json is supported", 
            detailed_message: null 
        })); 
        return; 
    } 
    oracledb.getConnection(connAttrs, function (err, connection) { 
        if (err) { 
            // Error connecting to DB 
            res.set('Content-Type', 'application/json').status(500).send(JSON.stringify({ 
                status: 500, 
                message: "Error connecting to DB", 
                detailed_message: err.message 
            })); 
            return; 
        } 
		
		connection.execute("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE; ", {}, (err, result) => {
                if (err) {
                    connection.rollback();
                } else {
					connection.commit();
                }
            });
 
        connection.execute(`SELECT * FROM (SELECT * FROM PROFILE WHERE "email" = :id AND "role" = 'Admin') WHERE "password" = :ip`,   
            {  
                id: req.body.email,  
                ip: req.body.password  
            }, {  
                outFormat: oracledb.OBJECT // Return the result as Object  
            }, (err, result) => {  
      
            if (err || result.rows.length < 1) {  
           connection.rollback(); 
                    connection.release(  
                        function (err) {  
                            if (err) {  
                                console.error(err.message);  
                            } else { 
							res.contentType('application/json').status(200).send(JSON.stringify({ 
							status: 404, 
							message: "not_updated" 
						   })); 
                                console.log("delete error: Connection released");  
                            }  
                        });    
                } else {  
				 connection.execute(`DELETE FROM ITEM WHERE "em" = :user_email`,  [req.body.user_email], { 
				  autoCommit: true, 
				  outFormat: oracledb.OBJECT // Return the result as Object 
				 }, (err, result) => { 
				  if (err) { 
				   // Error 
				   res.set('Content-Type', 'application/json'); 
				   res.status(400).send(JSON.stringify({ 
					status: 400, 
					message: err.message.indexOf("ORA-00001") > -1 ? "delete err" : "Input Error", 
					detailed_message: err.message 
				   })); 
				   connection.rollback(); 
				  } else { 
				  res.status(200).send(JSON.stringify({ 
					status: 200, 
					message: "Deleted" 
					})); 
				connection.commit(); 
				  } 
				 }); 
             }   
    }); 
});
}); 



var server = app.listen(3000, function () {
    "use strict";

    var host = server.address().address,
        port = server.address().port;

console.log(host)
    console.log(' Server is listening at http://%s:%s', host, port);
});